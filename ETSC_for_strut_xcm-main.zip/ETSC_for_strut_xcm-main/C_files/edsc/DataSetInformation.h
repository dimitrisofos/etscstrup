#include <string>

const int DIMENSION = 144;
const int ROWTRAINING = 288;
const int ROWTESTING = 72;
const char* trainingFileName="C_files/edsc/Data/train";
const char* testingFileName="C_files/edsc/Data/test";
const char* resultFileName="C_files/edsc/Data/result.txt";
const char* path ="C_files/edsc";
const int  NofClasses = 2;
const int Classes[] = {1,0};
const int ClassIndexes[] = {0,144};
const int ClassNumber[] = {144,144};
