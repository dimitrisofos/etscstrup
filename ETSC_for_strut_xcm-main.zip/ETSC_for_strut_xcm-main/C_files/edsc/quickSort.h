void quicksort(double a[],int start,int end);
